function [output,value] = AER(fixed, func, submodular, params, suppress_output)
%AER algorithm
%   fixed is a vector of 0, 0.5, or 1
% func is profit function name as string
% submodular is true or false, depending on if profit function submodular or not
% params: optional struct to pass parameters for profit function
% suppress_output: true or false if want to show result every time

fh=str2func(func);

if isempty(find(fixed==0.5))
    output=fixed;
    value=fh(fixed,params);
else
    out=AE(fixed, func, submodular, params, suppress_output);
    if isempty(find(out==0.5))
        output=out;
        value=fh(out,params);
        return;
    else
        %display(length(find(out==0.5)))
        to_fix=find(out==0.5,1);
    end
    fixed_0=out;
    fixed_0(to_fix)=0;
    fixed_1=out;
    fixed_1(to_fix)=1;
    [out_0, val_0]=AER(fixed_0, func, submodular, params, suppress_output);
    [out_1, val_1]=AER(fixed_1, func, submodular, params, suppress_output);
    
    if val_0>val_1
        output=out_0;
        value=val_0;
        return;
    else
        output=out_1;
        value=val_1;
        return;
    end
    
    
end


end

