function [output] = AE(fixed, func, submodular, params, suppress_output)
%AE algorithm 
%   fixed is a vector of 0, 0.5, or 1
% func is profit function name
% submodular is true or false, depending on if profit function submodular or not
% params: optional struct to pass parameters for profit function
% suppress_output: true or false if want to show result every time
if ~exist('params','var')
     % if parameters don't exist, so default it to something
      params = [];
end
if ~exist('suppress_output','var')
     % if suppress_output doesn't exist, so default it to something
      suppress_output = true;
end

exit_condition=true;
output=fixed;

while exit_condition
    output_prev=output;
    supr=output;
    infi=output;
    
    free_indices=find(output_prev==0.5);

    if ~suppress_output
        disp(length(free_indices))
    end
    
    supr(free_indices)=1;
    infi(free_indices)=0;

    if submodular
        for i=1:length(free_indices)
            index=free_indices(i);
            upper=marg(supr,index,func,params);
            lower=marg(infi,index,func,params);
            
            if upper<0 && lower<0
                output(index)=0;
%                 free_indices(i)=[];
            elseif lower>=0 && upper >=0
                output(index)=1;
%                 free_indices(i)=[];
            end
        end
    else
        for i=1:length(free_indices)
            index=free_indices(i);
            upper=marg(supr,index,func,params);
            lower=marg(infi,index,func,params);
            
            if upper>0 && lower>0
                output(index)=0;
                free_indices(i)=[];
            elseif lower<=0 && upper <=0
                output(index)=1;
                free_indices(i)=[];
            end
        end
    end
    
    if output==output_prev
        exit_condition=false;
    end
    
    
end



end

