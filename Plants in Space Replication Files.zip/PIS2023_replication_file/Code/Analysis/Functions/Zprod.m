function [prod] = Zprod(q,N,sigma)
%calculate Z to use based on q, # plants, and sigma
%   can switch between forms
prod=q/(1+N^sigma);
% prod=q*exp(-N/sigma); 
% prod=1;
end

