function [output] = marg(val,i, func, params)
%written almost exactly like it is in python
%calculates marginal value between a coordinate being one or zero
%   check if params exists or not, then calc marginal value
% if ~exist('params','var')
%      % if parameters don't exist, so default it to something
%       params = [];
% end
fh=str2func(func);
storage=val(i);

val_plus=val;
val_plus(i)=1;
high=fh(val_plus,params);

val_low=val;
val_low(i)=0;
low=fh(val_low,params);

val(i)=storage;

output=high-low;

if length(val)<=5
    disp(val_plus)
    disp(high)
    disp(val_low)
    disp(low)
end


end

