

% This file creates two plots of the appendix G in the draft.
% The first one shows the normalized tightest bound within the range of delta.
% The second one presents the log of the average of establishments implied
% by the upper and the lower bound for the case of k = 0.005. 

% Last update : 02/28/2023
clear all
close all
clc

datadir = '..\..\Data\Final\FigureG1\';
figdir = '..\..\Plots\';
load([datadir 'values01']);
load([datadir 'values01']);
load([datadir 'values001']); 
load([datadir 'values02']);
load([datadir 'values05']); 
load([datadir 'values005']); 
load([datadir 'values0005']); 
load([datadir 'values025']);
load([datadir 'values0025']);
load([datadir 'values033']);
load([datadir 'values01111']);
load([datadir 'values01250']); 
load([datadir 'values01429']);
load([datadir 'values01667']);


set(gca, 'XDir','reverse');

Diff_bound = [Diff_Bound_01' Diff_Bound_001' Diff_Bound_02' Diff_Bound_05' Diff_Bound_005' Diff_Bound_0005' Diff_Bound_025' ...
   Diff_Bound_0025' Diff_Bound_033' Diff_Bound_01111' Diff_Bound_01250' Diff_Bound_01429' Diff_Bound_01667'];
Diff_cont = min(Diff_bound');

Diff_cont_spline = pchip(Delta_vec',Diff_cont);
Cont = @(D) ppval(Diff_cont_spline,D);

D_vec(1) = 1;
value(1) = Cont(D_vec(1));
for i=2:1000
    D_vec(i)=D_vec(i-1)/1.5;
    value(i) = Cont(D_vec(i));
end

fig1 = figure(1);
qh1=plot(D_vec,value,'linewidth',2.5,'Color',[0 0 0]);
axis([D_vec(end) D_vec(1) min(value) max(value)])
set(gca, 'XDir','reverse')
th=ylabel("Normalized range within bounds, $\frac{\bar \pi^{k(\Delta)\Delta}-\underline \pi^{k(\Delta)\Delta}}{\frac{1}{2}(\bar \pi^{k(\Delta)\Delta}+\underline \pi^{k(\Delta)\Delta)}}$");
set(th,'Fontsize',12,'Interpreter','Latex')
th=xlabel("$\Delta$");
set(th,'Fontsize',12,'Interpreter','Latex')

saveas(fig1,[figdir 'FigureG1_left'],'png')

%%
n=7;
nn=20;
fig2 = figure(2);
plot(Delta_vec(n:nn),(N_005(n:nn,1)+N_005(n:nn,2))/2,'linewidth',2.5,'Color',[0 0 0])
axis([Delta_vec(nn) Delta_vec(n) (N_005(n,1)+N_005(n,2))/2 (N_005(nn,1)+N_005(nn,2))/2])
set(gca, 'XDir','reverse')
set(gca, 'YScale', 'log')
th=ylabel({"Average number of total establishments","implied by bounds"});
set(th,'Fontsize',12,'Interpreter','Latex');
th=xlabel("$\Delta$");
set(th,'Fontsize',12,'Interpreter','Latex');
saveas(fig2,[figdir 'FigureG1_right'],'png');
