# This file processes the .tex files outputted by Stata and 
# reformats them as they appear in the draft.

setwd("C:/Plants_in_Space/Tables")

# Table I
tableI = readLines("TableI.tex")
tableI_new = vector(mode="character", length=length(tableI))

tableI_new[1] = tableI[1]
tableI_new[2:3] = tableI[3:4]
tableI_new[4] = paste(tableI[5], "\\hline", sep = " ", collapse = NULL)
tableI_new[5] = tableI[2]
tableI_new[6] = substring(tableI[6], 10, nchar(tableI[6]))
tableI_new[7:length(tableI_new)] = tableI[7:length(tableI)]

writeLines(tableI_new, "TableI_clean.tex")

# Table II
tableII = readLines("TableII.tex")
tableII_new = vector(mode="character", length=length(tableII)+1)

tableII_new[1] = tableII[1]
tableII_new[2] = tableII[5]
tableII_new[3] = paste("\\textit{By major industry}", tableII[3], "\\hline", sep = " ", collapse = NULL)
tableII_new[4] = tableII[2]
tableII_new[5] = substring(tableII[4], 10, nchar(tableII[4]))
tableII_new[6:length(tableII_new)] = tableII[5:length(tableII)]

writeLines(tableII_new, "TableII_clean.tex")

# Table III
tableIII = readLines("TableIII.tex")
tableIII_new = vector(mode="character", length=length(tableIII))

tableIII_new[1] = tableIII[1]
tableIII_new[2:3] = tableIII[3:4]
tableIII_new[4] = paste(tableIII[5], "\\hline", sep = " ", collapse = NULL)
tableIII_new[5] = tableIII[2]
tableIII_new[6] = substring(tableIII[6], 10, nchar(tableIII[6]))
tableIII_new[7:length(tableIII_new)] = tableIII[7:length(tableIII)]

writeLines(tableIII_new, "TableIII_clean.tex")

# Table IV
tableIV = readLines("TableIV.tex")
tableIV_new = vector(mode="character", length=length(tableIV))

tableIV_new[1] = tableIV[1]
tableIV_new[2:3] = tableIV[3:4]
tableIV_new[4] = paste(tableIV[5], "\\hline", sep = " ", collapse = NULL)
tableIV_new[5] = tableIV[2]
tableIV_new[6] = substring(tableIV[6], 10, nchar(tableIV[6]))
tableIV_new[7:length(tableIV_new)] = tableIV[7:length(tableIV)]

writeLines(tableIV_new, "TableIV_clean.tex")

# Table V
tableV_1 = readLines("TableV_panel1.tex")
tableV_2 = readLines("TableV_panel2.tex")
tableV_3 = readLines("TableV_panel3.tex")
tableV_4 = readLines("TableV_panel4.tex")
tableV_5 = readLines("TableV_panel5.tex")
tableV_6 = readLines("TableV_panel6.tex")

tableV_new = vector(mode="character", length=63)
tableV_new[1:2] = tableV_1[1:2]
tableV_new[3] = substring(tableV_1[3], 10, nchar(tableV_1[3]))
tableV_new[4] = tableV_1[4]
tableV_new[5] = paste("\\textit{Baseline}", tableV_1[4], sep = " ", collapse = NULL)
tableV_new[6:12] = tableV_1[5:11]

tableV_new[13] = tableV_2[4]
tableV_new[14] = paste("\\textit{Firms with at least X plants}", substring(tableV_2[3], 10, nchar(tableV_2[3])-7), sep = " ", collapse = NULL)
tableV_new[15:21] = tableV_2[5:11]

tableV_new[22] = tableV_3[4]
tableV_new[23] = paste("\\textit{Controlling for HQ location, firms with at least X plants}", substring(tableV_3[3], 10, nchar(tableV_3[3])-7), sep = " ", collapse = NULL)
tableV_new[24:31] = tableV_3[5:12]

tableV_new[32] = tableV_4[4]
tableV_new[33] = paste("\\textit{Industries where largest firm has at least X plants}", substring(tableV_4[3], 10, nchar(tableV_4[3])-7), sep = " ", collapse = NULL)
tableV_new[34:40] = tableV_4[5:11]

tableV_new[41] = tableV_5[4]
tableV_new[42] = paste("\\textit{Controlling for HQ location, industries where largest firm has at least X plants}", substring(tableV_5[3], 10, nchar(tableV_5[3])-7), sep = " ", collapse = NULL)
tableV_new[43:50] = tableV_5[5:12]

tableV_new[51] = tableV_6[5]
tableV_new[52] = tableV_6[3]
tableV_new[53] = substring(tableV_6[4], 10, nchar(tableV_6[4])-7)
tableV_new[54:60] = tableV_6[6:12]
tableV_new[61:63] = tableI[(length(tableI)-2):length(tableI)]

writeLines(tableV_new, "TableV_clean.tex")

# Table VI
tableVI_1 = readLines("TableVI_panel1.tex")
tableVI_2 = readLines("TableVI_panel2.tex")
tableVI_3 = readLines("TableVI_panel3.tex")
tableVI_4 = readLines("TableVI_panel4.tex")
tableVI_5 = readLines("TableVI_panel5.tex")

tableVI_new = vector(mode="character", length=52)

tableVI_new[1:2] = tableVI_1[1:2]
tableVI_new[3] = substring(tableVI_1[3], 10, nchar(tableVI_1[3]))
tableVI_new[4] = tableVI_1[4]
tableVI_new[5] = paste("\\textit{Baseline}", tableVI_1[4], sep = " ", collapse = NULL)
tableVI_new[6:12] = tableVI_1[5:11]

tableVI_new[13] = tableVI_2[4]
tableVI_new[14] = paste("\\textit{Firms with at least X plants}", substring(tableVI_2[3], 10, nchar(tableVI_2[3])-7), sep = " ", collapse = NULL)
tableVI_new[15:21] = tableVI_2[5:11]

tableVI_new[22] = tableVI_3[4]
tableVI_new[23] = paste("\\textit{Industries where largest firm has at least X plants}", substring(tableVI_3[3], 10, nchar(tableVI_3[3])-7), sep = " ", collapse = NULL)
tableVI_new[24:30] = tableVI_3[5:11]

tableVI_new[31] = tableVI_4[4]
tableVI_new[32] = paste("\\textit{By major industry}", substring(tableVI_4[3], 10, nchar(tableVI_4[3])-7), sep = " ", collapse = NULL)
tableVI_new[33:39] = tableVI_4[5:11]

tableVI_new[40] = tableVI_5[5]
tableVI_new[41] = tableVI_5[3]
tableVI_new[42] = substring(tableVI_5[4], 10, nchar(tableVI_5[4])-7)
tableVI_new[43:49] = tableVI_5[6:12]
tableVI_new[50:52] = tableI[(length(tableI)-2):length(tableI)]

writeLines(tableVI_new, "TableVI_clean.tex")

# Table VII
tableVII_1 = readLines("TableVII_panel1.tex")
tableVII_2 = readLines("TableVII_panel2.tex")
tableVII_3 = readLines("TableVII_panel3.tex")
tableVII_4 = readLines("TableVII_panel4.tex")

tableVII_new = vector(mode="character", length=58)

tableVII_new[1:2] = tableVII_1[1:2]
tableVII_new[3] = substring(tableVII_1[3], 10, nchar(tableVII_1[3]))
tableVII_new[4] = tableVII_1[4]
tableVII_new[5] = paste("\\textit{Baseline}", tableVII_1[4], sep = " ", collapse = NULL)
tableVII_new[6:16] = tableVII_1[5:15]

tableVII_new[17] = tableVII_2[4]
tableVII_new[18] = paste("\\textit{Firms with at least X plants}", substring(tableVII_2[3], 10, nchar(tableVII_2[3])-7), sep = " ", collapse = NULL)
tableVII_new[19:29] = tableVII_2[5:15]

tableVII_new[30] = tableVII_3[4]
tableVII_new[31] = paste("\\textit{Industries where largest firm has at least X plants}", substring(tableVII_3[3], 10, nchar(tableVII_3[3])-7), sep = " ", collapse = NULL)
tableVII_new[32:42] = tableVII_3[5:15]

tableVII_new[43] = tableVII_4[4]
tableVII_new[44] = paste("\\textit{By major industry}", substring(tableVII_4[3], 10, nchar(tableVII_4[3])-7), sep = " ", collapse = NULL)
tableVII_new[45:55] = tableVII_4[5:15]
tableVII_new[56:58] = tableI[(length(tableI)-2):length(tableI)]

writeLines(tableVII_new, "TableVII_clean.tex")

# Table VIII
tableVIII_1 = readLines("TableVIII_panel1.tex")
tableVIII_2 = readLines("TableVIII_panel2.tex")
tableVIII_3 = readLines("TableVIII_panel3.tex")

tableVIII_new = vector(mode="character", length=47)

tableVIII_new[1:2] = tableVIII_1[1:2]
tableVIII_new[3] = substring(tableVIII_1[3], 10, nchar(tableVIII_1[3]))
tableVIII_new[4:15] = tableVIII_1[4:15]

tableVIII_new[16:31] = tableVIII_2[4:19]

tableVIII_new[32] = tableVIII_3[4]
tableVIII_new[33] = paste("\\textit{Non-Imputed}", tableVIII_3[4], sep = " ", collapse = NULL)
tableVIII_new[34:44] = tableVIII_3[5:15]
tableVIII_new[45:47] = tableI[(length(tableI)-2):length(tableI)]

writeLines(tableVIII_new, "TableVIII_clean.tex")


# Table X
tableX = readLines("TableX.tex")
tableX_new = vector(mode="character", length=length(tableX))

tableX_new[1] = tableX[1]
tableX_new[2:3] = tableX_new[3:4]
tableX_new[4] = paste(tableX[5], "\\hline", sep = " ", collapse = NULL)
tableX_new[5:length(tableX_new)] = tableX[5:length(tableX)]

writeLines(tableX_new, "TableX_clean.tex")